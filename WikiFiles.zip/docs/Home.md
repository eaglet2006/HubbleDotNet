**Project Description**
HubbleDotNet (Hubble.net) is an open-source full-text search database project based on .Net Framework.  Full-text search database system different from the tradition relational database system, which allows users to easily search the full text information, but it also provides a database field in the logical query. At present some of the major databases provide full-text search function, but there full-text search function is relatively weak, can not be well positioned to meet the practical application needs, and some full-text search components, such as the more well-known “Lucene”, only provides the full-text search function, while the lack of linking with the relational database. Hubble.net is one of the new database system that can unite full-text search and relational query. Users can easily do full-text search, relationship query even relationship query plus full-text search  through SQL.
Hubble.net provides a SQL-based full-text search interface, users only need to operate SQL, can quickly learn how to use Hubble.net full-text search. Hubble.net can achieve full-text indexing and querying, multi-field searching and sorting, grouping statistics, distinct, classification, clustering, multi-table queries, and other a series of full-text search and data mining features. Hubble.net provides a database adapter interface and can be the perfect integration of various databases for data mining and full-text search features. Hubble.net designed a more perfect concurrency control procedures, data additions, deletions, updating or query can be executed as multi-threading without any conflict. Hubble.net also providers the cache and memory management is designed to help users to maximize the improvement of query efficiency. In the next few years, I think hubble.net will be the most popular full-text search component in .Net development environment.

## [HubbleDotNet's home page](http://www.hubbledotnet.com/)

## [HubbleDotNet's blog](http://hubbledotnet.blogspot.com/)

## [User statistic](http://www.hubbledotnet.com/statistichb.aspx)

## [Documentation](http://hubbledotnet.codeplex.com/documentation)  [Test data download](http://hubbledotnet.codeplex.com/releases/view/36585) 

## [Mailing Lists](http://groups.google.com/group/hubble-dev)
Discussion about the project occurs on its mailing list, [http://groups.google.com/group/hubble-dev](http://groups.google.com/group/hubble-dev)
## News
* 19 Mar 2012 - Released HubbleDotNet 1.2.0.0
* 22 Feb 2011- Released HubbleDotNet 1.1.0.0
* 25 Aug 2010 - Released HubbleDotNet0.9.6.0
* 03 May 2010 - Released HubbleDotNet 0.8.3.0
* 18 December 2009 - Released HubbleDotNet 0.7.2.0
* 14 December 2009 - Released HubbleDotNet 0.7.1.0
* 30 November 2009 - Released HubbleDotNet 0.7.0.0 

## Features
* Index
* Search
* Delete
* Update
* SQL-based SQLClient interface 
* Index-level cache 
* Query-level cache 
* Data-level cache 
* Multi-field sorting
* Concurrency control
* Queries combinate Full-text and metadata 
* Keyword rank specified
* Field rank specified
* Record rank  specified
* Index optimization
* Custom analyzer
* Custom database adapter 
* System Stored Procedures 
* Query Analyzer 
## Tools
[HBTextParse](http://hubbledotnet.codeplex.com/releases/view/100117)
