# Run Installation Package

Download Setup.exe from download tab in Hubble.net Project Web Site http://hubbledotnet.codeplex.com/

Please download the setup.exe according to your operating system.

We have three versions of setup.exe

   1. x86/setup.exe
   2. x64/setup.exe
   3. IA/setup.exe

# Installation Steps

## Welcome

Click Next in Welcome window
![](Installation_clip_image002_thumb.jpg)
welcome


## Register

![](Installation_clip_image004_thumb.jpg)

Registratoin is for information purpose only. You can register and get installation key at this Page

Click submit button after filling the form. Your installation key will be sent to your registered email address. If you haven't got the email, please check in your spam or junk email folders, or you can register again

Please note, we are having problem to send email to sina.com. Please do not use email address from sina.com.

If you still have problem to visit this page, you can send following information to Hubble.net@gmail.com. We can help you on this registration:

1. Your email address
2. Your country
3. Your name

Click Next after typed in email address and key

## Select installation directary

![](Installation_clip_image006_thumb.jpg)


Choose your installation directory, then click Next

Confirm your installation in pop up dialog

Installation is finished.